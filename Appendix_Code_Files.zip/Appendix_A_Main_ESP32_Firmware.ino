/*
  ===================================================================================
  ESP32 Industrial Motor Health & Safety Monitoring System + HiveMQ Cloud & SCADA
  ===================================================================================
  Hardware Pin Mapping:
    - Voltage Sensor ZMPT101B : GPIO 32 (ADC1_CH4 - Compatible with Wi-Fi)
    - Current Sensor ACS712 30A: GPIO 35 (ADC1_CH7)
    - DS18B20 Temp Sensor   : GPIO 4  (OneWire Bus - Requires 4.7k pull-up resistor)
    - SW-420 Vibration      : GPIO 39 (VN Pin / SENSOR_VN)
    - LM393 Speed Sensor    : GPIO 34 (Input-only Pin - Hardware Interrupt for RPM)
    - Protection Relay      : GPIO 26 (Digital Output - Active LOW)
    - Fault Alarm Buzzer    : GPIO 5  (Digital Output)
    - 20x4 I2C LCD Display  : GPIO 21 (SDA), GPIO 22 (SCL)
  ===================================================================================
*/

#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <PubSubClient.h>
#include <WebServer.h>
#include <Preferences.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <ZMPT101B.h>
#include "dashboard.h"

// -----------------------------------------------------------------------------------
// HARDWARE PIN DEFINITIONS
// -----------------------------------------------------------------------------------
#define VOLTAGE_PIN         32    // ZMPT101B Voltage Sensor Analog Input (GPIO 32 - ADC1)
#define CURRENT_PIN         35    // ACS712 30A Current Sensor Analog Input
#define TEMP_PIN            4     // DS18B20 OneWire Data Pin
#define VIBRATION_PIN       39    // SW-420 Vibration Digital Input (VN Pin)
#define SPEED_PIN           34    // LM393 Optical Speed Sensor Interrupt Input
#define RELAY_PIN           26    // Motor Safety Relay Output Pin (Active-LOW)
#define BUZZER_PIN          5     // Fault Alarm Buzzer Output Pin (GPIO 5)
#define SDA_PIN             21    // 20x4 LCD I2C SDA
#define SCL_PIN             22    // 20x4 LCD I2C SCL

// -----------------------------------------------------------------------------------
// ZMPT101B SENSOR CALIBRATION CONSTANTS
// -----------------------------------------------------------------------------------
#define SENSITIVITY         500.0f  // Sensitivity calibration
#define CALIBRATION_FACTOR  1.49f   // Calibration factor (230 / 155)
#define PULSES_PER_REV      20.0f   // Slots in encoder wheel
#define VCC_ADC             3.3f    // ESP32 ADC Max Voltage
#define ADC_RESOLUTION      4095.0f
#define ACS712_SENSITIVITY  0.066f  // 66mV/A for ACS712 30A model

// -----------------------------------------------------------------------------------
// DEFAULT CREDENTIALS (Saved to ESP32 Flash Memory via Preferences)
// -----------------------------------------------------------------------------------
char wifi_ssid[32]      = "Airtel_Zerotouch";
char wifi_pass[64]      = "Airtel@123";
char mqtt_server[128]   = "YOUR_MQTT_BROKER_HOST";
int  mqtt_port          = 8883;
char mqtt_user[64]      = "YOUR_MQTT_USERNAME";
char mqtt_pass[64]      = "YOUR_MQTT_PASSWORD";

// MQTT Topics
const char* topic_telemetry = "industrial/motor/telemetry";
const char* topic_control   = "industrial/motor/control";

// Dynamic Sensor Thresholds (Loaded from Preferences NVS)
float max_voltage_limit = 250.0; 
float min_voltage_limit = 180.0; 
float max_current_limit = 10.0;    // Over-current trip threshold (A)
float max_temp_limit    = 65.0;  
float max_rpm_limit     = 3000.0;  

// -----------------------------------------------------------------------------------
// GLOBAL OBJECTS
// -----------------------------------------------------------------------------------
LiquidCrystal_I2C lcd(0x27, 20, 4);
OneWire oneWire(TEMP_PIN);
DallasTemperature tempSensor(&oneWire);
ZMPT101B voltageSensor(VOLTAGE_PIN, 50.0); // ZMPT101B on GPIO 27, 50.0 Hz
WiFiClientSecure espClient;
PubSubClient mqttClient(espClient);
WebServer server(80);
Preferences preferences;

// -----------------------------------------------------------------------------------
// GLOBAL VARIABLES & INTERRUPT STATE
// -----------------------------------------------------------------------------------
volatile unsigned long pulseCount = 0;
unsigned long lastRpmCalcTime = 0;
unsigned long overSpeedStartTime = 0; // Timer for 8-second continuous over-speed protection delay

float zeroCurrentAdc = 2050.0;     // Calibrated zero-load baseline ADC value

float motorRpm = 0.0;
float lineVoltage = 0.0;
float motorCurrent = 0.0;
float motorTempC = 0.0;
bool vibrationDetected = false;

bool manualTrip = false;          // Latched User Remote Override State
bool relayState = true;           // true = ON / Closed (LOW), false = TRIP / Open (HIGH)
String faultStatus = "SYSTEM OK";

unsigned long lastSensorReadTime = 0;
unsigned long lastTempReadTime = 0;
unsigned long lastLcdUpdateTime = 0;
unsigned long lastMqttPubTime = 0;
unsigned long lastSerialPrintTime = 0;

// Function Prototypes
void calculateRpm(unsigned long timeElapsedMs);
void readAllSensors();
void evaluateProtectionLogic();
void updateLcdDisplay();
void publishMqttTelemetry();
void printSerialDiagnostics();
void loadSavedConfig();
void handleSaveConfig();
void handleRoot();
void handleApiData();
void handleApiControl();
void mqttCallback(char* topic, byte* payload, unsigned int length);
void reconnectMqtt();
void calibrateAcs712Zero();

// -----------------------------------------------------------------------------------
// INTERRUPT SERVICE ROUTINE
// -----------------------------------------------------------------------------------
void IRAM_ATTR speedSensorISR() {
  pulseCount++;
}

// -----------------------------------------------------------------------------------
// ACS712 ZERO-LOAD BASELINE CALIBRATION
// -----------------------------------------------------------------------------------
void calibrateAcs712Zero() {
  long sum = 0;
  for (int i = 0; i < 200; i++) {
    sum += analogRead(CURRENT_PIN);
    delay(2);
  }
  zeroCurrentAdc = (float)sum / 200.0;
  Serial.print(F("[CALIBRATION] ACS712 30A Zero-Load Baseline ADC: "));
  Serial.println(zeroCurrentAdc);
}

// -----------------------------------------------------------------------------------
// PREFERENCES CONFIGURATION FUNCTIONS
// -----------------------------------------------------------------------------------
void loadSavedConfig() {
  preferences.begin("motor_config", true);
  String s_ssid = preferences.getString("ssid", wifi_ssid);
  String s_pass = preferences.getString("pass", wifi_pass);
  String s_mserver = preferences.getString("mserver", mqtt_server);
  int s_mport = preferences.getInt("mport", mqtt_port);
  String s_muser = preferences.getString("muser", mqtt_user);
  String s_mpass = preferences.getString("mpass", mqtt_pass);

  max_voltage_limit = preferences.getFloat("v_max", 250.0);
  min_voltage_limit = preferences.getFloat("v_min", 180.0);
  max_current_limit = preferences.getFloat("i_max", 10.0);
  max_temp_limit    = preferences.getFloat("t_max", 65.0);
  max_rpm_limit     = preferences.getFloat("rpm_max", 3000.0);

  preferences.end();

  s_ssid.toCharArray(wifi_ssid, sizeof(wifi_ssid));
  s_pass.toCharArray(wifi_pass, sizeof(wifi_pass));
  s_mserver.toCharArray(mqtt_server, sizeof(mqtt_server));
  mqtt_port = s_mport;
  s_muser.toCharArray(mqtt_user, sizeof(mqtt_user));
  s_mpass.toCharArray(mqtt_pass, sizeof(mqtt_pass));
}

void handleSaveConfig() {
  preferences.begin("motor_config", false);
  if (server.hasArg("ssid")) preferences.putString("ssid", server.arg("ssid"));
  if (server.hasArg("pass")) preferences.putString("pass", server.arg("pass"));
  if (server.hasArg("mqtt_server")) preferences.putString("mserver", server.arg("mqtt_server"));
  if (server.hasArg("mqtt_port")) preferences.putInt("mport", server.arg("mqtt_port").toInt());
  if (server.hasArg("mqtt_user")) preferences.putString("muser", server.arg("mqtt_user"));
  if (server.hasArg("mqtt_pass")) preferences.putString("mpass", server.arg("mqtt_pass"));

  if (server.hasArg("v_max")) preferences.putFloat("v_max", server.arg("v_max").toFloat());
  if (server.hasArg("v_min")) preferences.putFloat("v_min", server.arg("v_min").toFloat());
  if (server.hasArg("i_max")) preferences.putFloat("i_max", server.arg("i_max").toFloat());
  if (server.hasArg("t_max")) preferences.putFloat("t_max", server.arg("t_max").toFloat());
  if (server.hasArg("rpm_max")) preferences.putFloat("rpm_max", server.arg("rpm_max").toFloat());

  preferences.end();

  String msg = "<html><body style='background:#0b0f19;color:#fff;font-family:sans-serif;padding:40px;text-align:center;'>";
  msg += "<h2>✅ Settings & Protection Thresholds Saved!</h2><p>Rebooting ESP32...</p></body></html>";
  server.send(200, "text/html", msg);
  delay(2000);
  ESP.restart();
}

void handleRoot() {
  String html = DASHBOARD_HTML;
  html.replace("%SSID%", wifi_ssid);
  html.replace("%PASS%", wifi_pass);
  html.replace("%MQTT_SERVER%", mqtt_server);
  html.replace("%MQTT_PORT%", String(mqtt_port));
  html.replace("%MQTT_USER%", mqtt_user);
  html.replace("%MQTT_PASS%", mqtt_pass);

  html.replace("%V_MAX%", String(max_voltage_limit, 1));
  html.replace("%V_MIN%", String(min_voltage_limit, 1));
  html.replace("%I_MAX%", String(max_current_limit, 1));
  html.replace("%T_MAX%", String(max_temp_limit, 1));
  html.replace("%RPM_MAX%", String(max_rpm_limit, 0));

  server.send(200, "text/html", html);
}

void handleApiData() {
  String json = "{";
  json += "\"voltage\":" + String(lineVoltage, 1) + ",";
  json += "\"current\":" + String(motorCurrent, 2) + ",";
  json += "\"rpm\":" + String(motorRpm, 0) + ",";
  json += "\"temp\":" + String(motorTempC, 1) + ",";
  json += "\"vibration\":" + String(vibrationDetected ? "true" : "false") + ",";
  json += "\"relay\":" + String(relayState ? "true" : "false") + ",";
  json += "\"manual_trip\":" + String(manualTrip ? "true" : "false") + ",";
  json += "\"v_max\":" + String(max_voltage_limit, 1) + ",";
  json += "\"v_min\":" + String(min_voltage_limit, 1) + ",";
  json += "\"i_max\":" + String(max_current_limit, 2) + ",";
  json += "\"t_max\":" + String(max_temp_limit, 1) + ",";
  json += "\"rpm_max\":" + String(max_rpm_limit, 0) + ",";
  json += "\"ssid\":\"" + String(wifi_ssid) + "\",";
  json += "\"mqtt_server\":\"" + String(mqtt_server) + "\",";
  json += "\"mqtt_port\":" + String(mqtt_port) + ",";
  json += "\"mqtt_user\":\"" + String(mqtt_user) + "\",";
  json += "\"status\":\"" + faultStatus + "\"";
  json += "}";
  server.send(200, "application/json", json);
}

void handleApiControl() {
  if (server.hasArg("state")) {
    String st = server.arg("state");
    if (st == "OFF" || st == "TRIP") {
      manualTrip = true;
      relayState = false;
      digitalWrite(RELAY_PIN, HIGH); // Active-LOW: HIGH = Relay OFF / Tripped
      digitalWrite(BUZZER_PIN, HIGH); // Buzzer Alarm ON
    } else if (st == "ON" || st == "RESET") {
      manualTrip = false;
      relayState = true;
      digitalWrite(RELAY_PIN, LOW);  // Active-LOW: LOW = Relay ON / Normal
      digitalWrite(BUZZER_PIN, LOW);  // Buzzer Alarm OFF
    }
  }
  server.send(200, "text/plain", "OK");
}

// -----------------------------------------------------------------------------------
// HIVEMQ MQTT FUNCTIONS
// -----------------------------------------------------------------------------------
void mqttCallback(char* topic, byte* payload, unsigned int length) {
  String message = "";
  for (unsigned int i = 0; i < length; i++) {
    message += (char)payload[i];
  }
  if (message == "OFF" || message == "TRIP") {
    manualTrip = true;
    relayState = false;
    digitalWrite(RELAY_PIN, HIGH); // Active-LOW: HIGH = Relay OFF / Tripped
    digitalWrite(BUZZER_PIN, HIGH); // Buzzer Alarm ON
  } else if (message == "ON" || message == "RESET") {
    manualTrip = false;
    relayState = true;
    digitalWrite(RELAY_PIN, LOW);  // Active-LOW: LOW = Relay ON / Normal
    digitalWrite(BUZZER_PIN, LOW);  // Buzzer Alarm OFF
  } else if (message.startsWith("CFG:")) {
    // Config update via MQTT: CFG:v_max=250.0;v_min=180.0;i_max=10.0;t_max=65.0;rpm_max=3000;
    preferences.begin("motor_config", false);
    if (message.indexOf("v_max=") != -1) {
      float val = message.substring(message.indexOf("v_max=") + 6).toFloat();
      if (val > 0) { max_voltage_limit = val; preferences.putFloat("v_max", val); }
    }
    if (message.indexOf("v_min=") != -1) {
      float val = message.substring(message.indexOf("v_min=") + 6).toFloat();
      if (val > 0) { min_voltage_limit = val; preferences.putFloat("v_min", val); }
    }
    if (message.indexOf("i_max=") != -1) {
      float val = message.substring(message.indexOf("i_max=") + 6).toFloat();
      if (val > 0) { max_current_limit = val; preferences.putFloat("i_max", val); }
    }
    if (message.indexOf("t_max=") != -1) {
      float val = message.substring(message.indexOf("t_max=") + 6).toFloat();
      if (val > 0) { max_temp_limit = val; preferences.putFloat("t_max", val); }
    }
    if (message.indexOf("rpm_max=") != -1) {
      float val = message.substring(message.indexOf("rpm_max=") + 8).toFloat();
      if (val > 0) { max_rpm_limit = val; preferences.putFloat("rpm_max", val); }
    }
    preferences.end();
  }
}

void reconnectMqtt() {
  if (!mqttClient.connected()) {
    String clientId = "ESP32MotorHub-" + String(random(0xffff), HEX);
    if (mqttClient.connect(clientId.c_str(), mqtt_user, mqtt_pass)) {
      mqttClient.subscribe(topic_control);
    }
  }
}

// -----------------------------------------------------------------------------------
// SETUP
// -----------------------------------------------------------------------------------
void setup() {
  Serial.begin(115200);
  pinMode(RELAY_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(VIBRATION_PIN, INPUT);
  pinMode(SPEED_PIN, INPUT);
  digitalWrite(RELAY_PIN, LOW);  // Active-LOW relay: LOW = Relay ON / Closed
  digitalWrite(BUZZER_PIN, LOW); // Buzzer OFF

  // Initialize ZMPT101B Sensitivity (Exactly as working test sketch)
  voltageSensor.setSensitivity(SENSITIVITY);

  // Auto-calibrate ACS712 30A Current Sensor zero-load baseline
  calibrateAcs712Zero();

  Wire.begin(SDA_PIN, SCL_PIN);
  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print(F("MOTOR HEALTH MONITOR"));

  loadSavedConfig();

  // Dual WiFi Mode: Station (connect to home router) + Access Point (Hotspot always broadcasted)
  WiFi.mode(WIFI_AP_STA);
  WiFi.softAP("ESP32-Motor-Monitor", "12345678"); // Hotspot Broadcast at 192.168.4.1
  WiFi.begin(wifi_ssid, wifi_pass);

  int attempt = 0;
  while (WiFi.status() != WL_CONNECTED && attempt < 12) {
    delay(500);
    attempt++;
  }

  if (WiFi.status() == WL_CONNECTED) {
    lcd.setCursor(0, 2);
    lcd.print(F("IP:"));
    lcd.print(WiFi.localIP());
  } else {
    lcd.setCursor(0, 2);
    lcd.print(F("AP: 192.168.4.1     "));
  }
  delay(1500);
  lcd.clear();

  server.on("/", handleRoot);
  server.on("/api/data", handleApiData);
  server.on("/api/control", HTTP_POST, handleApiControl);
  server.on("/save_config", HTTP_POST, handleSaveConfig);
  server.begin();

  espClient.setInsecure(); // SSL Mode for HiveMQ Cloud TLS
  mqttClient.setServer(mqtt_server, mqtt_port);
  mqttClient.setBufferSize(512); // Increase buffer size to fit full SCADA telemetry JSON
  mqttClient.setCallback(mqttCallback);

  tempSensor.begin();
  tempSensor.setWaitForConversion(false); // Non-blocking DS18B20 temperature reads
  attachInterrupt(digitalPinToInterrupt(SPEED_PIN), speedSensorISR, RISING);
}

// -----------------------------------------------------------------------------------
// LOOP
// -----------------------------------------------------------------------------------
void loop() {
  unsigned long currentMillis = millis();

  server.handleClient();

  if (WiFi.status() == WL_CONNECTED) {
    if (!mqttClient.connected()) {
      reconnectMqtt();
    }
    mqttClient.loop();
  }

  if (currentMillis - lastRpmCalcTime >= 500) {
    calculateRpm(currentMillis - lastRpmCalcTime);
    lastRpmCalcTime = currentMillis;
  }

  if (currentMillis - lastSensorReadTime >= 200) {
    readAllSensors();
    evaluateProtectionLogic();
    lastSensorReadTime = currentMillis;
  }

  if (currentMillis - lastLcdUpdateTime >= 250) {
    updateLcdDisplay();
    lastLcdUpdateTime = currentMillis;
  }

  if (currentMillis - lastMqttPubTime >= 500) {
    publishMqttTelemetry();
    lastMqttPubTime = currentMillis;
  }

  if (currentMillis - lastSerialPrintTime >= 1000) {
    printSerialDiagnostics();
    lastSerialPrintTime = currentMillis;
  }
}

// -----------------------------------------------------------------------------------
// SENSOR PROCESSING FUNCTIONS
// -----------------------------------------------------------------------------------
void calculateRpm(unsigned long timeElapsedMs) {
  noInterrupts();
  unsigned long count = pulseCount;
  pulseCount = 0;
  interrupts();
  motorRpm = ((float)count / PULSES_PER_REV) * (60000.0 / (float)timeElapsedMs);
}

void readAllSensors() {
  // ---------------------------------------------------------------------------------
  // 1. ZMPT101B VOLTAGE READING (Exact calculation as user test sketch)
  // ---------------------------------------------------------------------------------
  float voltage = voltageSensor.getRmsVoltage() * CALIBRATION_FACTOR;
  lineVoltage = voltage;
  Serial.print("Voltage: ");
  Serial.println(lineVoltage);

  // ---------------------------------------------------------------------------------
  // 2. ACS712 30A CURRENT READING (With Calibrated Zero-Load Baseline & Noise Gate)
  // ---------------------------------------------------------------------------------
  uint16_t minAdcI = 4095;
  uint16_t maxAdcI = 0;
  long adcSum = 0;

  for (int i = 0; i < 40; i++) {
    uint16_t adcVal = analogRead(CURRENT_PIN);
    adcSum += adcVal;
    if (adcVal > maxAdcI) maxAdcI = adcVal;
    if (adcVal < minAdcI) minAdcI = adcVal;
    delayMicroseconds(250);
  }

  float avgAdc = (float)adcSum / 40.0;
  float iPeakToPeak = ((float)(maxAdcI - minAdcI) / ADC_RESOLUTION) * VCC_ADC;

  float adcOffsetDiff = abs(avgAdc - zeroCurrentAdc);
  float vDiff = (adcOffsetDiff / ADC_RESOLUTION) * VCC_ADC;
  float currentFromOffset = vDiff / ACS712_SENSITIVITY;
  float currentFromP2P = ((iPeakToPeak / 2.0) * 0.7071) / ACS712_SENSITIVITY;

  motorCurrent = (currentFromOffset + currentFromP2P) / 2.0;

  if (motorCurrent < 0.38 || iPeakToPeak < 0.030) {
    motorCurrent = 0.00;
  }

  // ---------------------------------------------------------------------------------
  // 3. DS18B20 TEMPERATURE READING (Non-blocking every 2 seconds)
  // ---------------------------------------------------------------------------------
  if (millis() - lastTempReadTime >= 2000) {
    float readTemp = tempSensor.getTempCByIndex(0);
    if (readTemp != DEVICE_DISCONNECTED_C && readTemp > -40.0) motorTempC = readTemp;
    tempSensor.requestTemperatures();
    lastTempReadTime = millis();
  }

  // ---------------------------------------------------------------------------------
  // 4. SW-420 VIBRATION SENSOR READING
  // ---------------------------------------------------------------------------------
  vibrationDetected = (digitalRead(VIBRATION_PIN) == HIGH);
}

void evaluateProtectionLogic() {
  bool tripFault = false;
  faultStatus = (lineVoltage < 10.0f) ? "SYSTEM OK (AC MAINS OFF)" : "ALL SYSTEM OK";

  if (manualTrip) {
    faultStatus = "MANUAL OVERRIDE TRIP!";
    tripFault = true;
  } else if (lineVoltage > max_voltage_limit) {
    faultStatus = "OVER VOLTAGE TRIP!";
    tripFault = true;
  } else if (lineVoltage >= 10.0f && lineVoltage < min_voltage_limit) {
    faultStatus = "UNDER VOLTAGE TRIP!";
    tripFault = true;
  } else if (motorCurrent > max_current_limit) {
    faultStatus = "OVER CURRENT TRIP!";
    tripFault = true;
  } else if (motorTempC > max_temp_limit) {
    faultStatus = "OVER TEMP TRIP!";
    tripFault = true;
  } else if (vibrationDetected) {
    faultStatus = "EXCESS VIBRATION!";
    tripFault = true;
  } else if (motorRpm > max_rpm_limit) {
    if (overSpeedStartTime == 0) {
      overSpeedStartTime = millis(); // Start 8-second continuous over-speed timer
    }
    unsigned long elapsed = millis() - overSpeedStartTime;
    if (elapsed >= 8000) {
      faultStatus = "OVER SPEED TRIP (8s EXCEEDED)!";
      tripFault = true;
    } else {
      // Temporary surge - keep relay ON, warn user of countdown
      int remainingSec = 8 - (int)(elapsed / 1000);
      if (remainingSec < 1) remainingSec = 1;
      faultStatus = "RPM SURGE WARN (" + String(remainingSec) + "s)";
      tripFault = false;
    }
  } else {
    overSpeedStartTime = 0; // Reset timer when RPM returns to normal
  }

  if (tripFault) {
    relayState = false;
    digitalWrite(RELAY_PIN, HIGH); // Active-LOW Relay OFF / Tripped
    digitalWrite(BUZZER_PIN, HIGH); // Fault Alarm Buzzer ON
  } else {
    relayState = true;
    digitalWrite(RELAY_PIN, LOW);  // Active-LOW Relay ON / Closed
    digitalWrite(BUZZER_PIN, LOW);  // Fault Alarm Buzzer OFF
  }
}

void updateLcdDisplay() {
  lcd.setCursor(0, 0);
  lcd.print(F("V:"));
  if (lineVoltage < 100.0) lcd.print(F(" "));
  lcd.print(lineVoltage, 1);
  lcd.print(F("V I:"));
  if (motorCurrent < 10.0) lcd.print(F(" "));
  lcd.print(motorCurrent, 2);
  lcd.print(F("A  "));

  lcd.setCursor(0, 1);
  lcd.print(F("RPM:"));
  int rpmInt = (int)motorRpm;
  if (rpmInt < 1000) lcd.print(F(" "));
  if (rpmInt < 10) lcd.print(F(" "));
  if (rpmInt < 10) lcd.print(F(" "));
  lcd.print(rpmInt);
  lcd.print(F(" T:"));
  lcd.print(motorTempC, 1);
  lcd.print(F("C  "));

  lcd.setCursor(0, 2);
  lcd.print(F("VIB:"));
  lcd.print(vibrationDetected ? F("WARN ") : F("NORM "));
  lcd.print(F("RLY:"));
  lcd.print(relayState ? F("ON  ") : F("TRIP"));

  lcd.setCursor(0, 3);
  if (WiFi.status() == WL_CONNECTED) {
    lcd.print(F("IP:"));
    lcd.print(WiFi.localIP().toString().substring(0, 17));
  } else {
    lcd.print(F("ST:"));
    lcd.print(faultStatus.substring(0, 17));
  }
}

void publishMqttTelemetry() {
  if (mqttClient.connected()) {
    String jsonPayload = "{";
    jsonPayload += "\"voltage\":" + String(lineVoltage, 1) + ",";
    jsonPayload += "\"current\":" + String(motorCurrent, 2) + ",";
    jsonPayload += "\"rpm\":" + String(motorRpm, 0) + ",";
    jsonPayload += "\"temperature\":" + String(motorTempC, 1) + ",";
    jsonPayload += "\"vibration\":" + String(vibrationDetected ? 1 : 0) + ",";
    jsonPayload += "\"relay\":" + String(relayState ? 1 : 0) + ",";
    jsonPayload += "\"v_max\":" + String(max_voltage_limit, 1) + ",";
    jsonPayload += "\"v_min\":" + String(min_voltage_limit, 1) + ",";
    jsonPayload += "\"i_max\":" + String(max_current_limit, 2) + ",";
    jsonPayload += "\"t_max\":" + String(max_temp_limit, 1) + ",";
    jsonPayload += "\"rpm_max\":" + String(max_rpm_limit, 0) + ",";
    jsonPayload += "\"ssid\":\"" + String(wifi_ssid) + "\",";
    jsonPayload += "\"mqtt_server\":\"" + String(mqtt_server) + "\",";
    jsonPayload += "\"mqtt_port\":" + String(mqtt_port) + ",";
    jsonPayload += "\"mqtt_user\":\"" + String(mqtt_user) + "\",";
    jsonPayload += "\"status\":\"" + faultStatus + "\"";
    jsonPayload += "}";

    bool pubResult = mqttClient.publish(topic_telemetry, jsonPayload.c_str());
    Serial.print(F(" MQTT Telemetry Publish: "));
    if (pubResult) {
      Serial.println(F("SUCCESS (Topic: industrial/motor/telemetry)"));
    } else {
      Serial.println(F("FAILED (Packet size or buffer limit exceeded)"));
    }
  }
}

void printSerialDiagnostics() {
  Serial.println(F("====================================================="));
  Serial.println(F("       ESP32 MOTOR MONITORING REAL-TIME DIAGNOSTICS  "));
  Serial.println(F("====================================================="));
  Serial.print(F(" Voltage      : ")); Serial.print(lineVoltage, 1); Serial.println(F(" V"));
  Serial.print(F(" Current      : ")); Serial.print(motorCurrent, 2); Serial.println(F(" A"));
  Serial.print(F(" Motor Speed  : ")); Serial.print(motorRpm, 0); Serial.println(F(" RPM"));
  Serial.print(F(" Temperature  : ")); Serial.print(motorTempC, 1); Serial.println(F(" deg C"));
  Serial.print(F(" Vibration    : ")); Serial.println(vibrationDetected ? F("WARN (Vibration Detected)") : F("NORMAL"));
  Serial.print(F(" Relay State  : ")); Serial.println(relayState ? F("ON (Normal)") : F("TRIPPED (Buzzer ON)"));
  Serial.print(F(" System Status: ")); Serial.println(faultStatus);
  Serial.print(F(" Wi-Fi IP     : ")); 
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println(WiFi.localIP());
  } else {
    Serial.println(F("Hotspot Mode (192.168.4.1)"));
  }
  Serial.print(F(" MQTT Broker  : ")); Serial.println(mqttClient.connected() ? F("CONNECTED (HiveMQ SSL)") : F("DISCONNECTED"));
  Serial.println(F("=====================================================\n"));
}