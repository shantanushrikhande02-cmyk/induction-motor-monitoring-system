#ifndef DASHBOARD_H
#define DASHBOARD_H

#include <Arduino.h>

const char DASHBOARD_HTML[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ESP32 Motor Protection - Configuration Portal (192.168.4.1)</title>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;700;800&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">
  <style>
    :root {
      --bg: #070b14;
      --panel: #0f172a;
      --border: #1e293b;
      --accent: #3b82f6;
      --accent-glow: rgba(59, 130, 246, 0.4);
      --success: #10b981;
      --warning: #f59e0b;
      --danger: #ef4444;
      --text: #f8fafc;
      --muted: #94a3b8;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Outfit', sans-serif; }
    body {
      background: radial-gradient(circle at top center, #111e38 0%, var(--bg) 70%);
      color: var(--text);
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 20px;
    }
    .config-card {
      background: var(--panel);
      border: 1px solid var(--border);
      border-radius: 16px;
      padding: 32px;
      max-width: 780px;
      width: 100%;
      box-shadow: 0 20px 50px rgba(0,0,0,0.7), 0 0 30px rgba(59, 130, 246, 0.15);
    }
    .header {
      text-align: center;
      margin-bottom: 28px;
      padding-bottom: 20px;
      border-bottom: 1px solid var(--border);
    }
    .header h1 {
      font-size: 1.6rem;
      font-weight: 800;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
    }
    .header p {
      color: var(--muted);
      font-size: 0.9rem;
      margin-top: 6px;
    }
    .badge {
      display: inline-block;
      padding: 4px 12px;
      border-radius: 20px;
      font-size: 0.8rem;
      font-weight: 700;
      font-family: 'JetBrains Mono', monospace;
      background: rgba(16, 185, 129, 0.15);
      color: var(--success);
      border: 1px solid rgba(16, 185, 129, 0.3);
      margin-top: 10px;
    }
    .section-title {
      font-size: 1rem;
      font-weight: 700;
      color: var(--accent);
      margin: 22px 0 14px 0;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .form-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 16px;
    }
    .form-group {
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .form-group label {
      font-size: 0.82rem;
      color: var(--muted);
      font-weight: 600;
    }
    .form-group input {
      background: #090e1a;
      border: 1px solid var(--border);
      border-radius: 8px;
      padding: 10px 14px;
      color: #fff;
      font-size: 0.95rem;
      font-family: 'JetBrains Mono', monospace;
      outline: none;
      transition: all 0.2s ease;
    }
    .form-group input:focus {
      border-color: var(--accent);
      box-shadow: 0 0 12px var(--accent-glow);
    }
    .btn-save {
      width: 100%;
      background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
      color: #fff;
      border: none;
      padding: 14px;
      border-radius: 10px;
      font-weight: 700;
      font-size: 1rem;
      cursor: pointer;
      margin-top: 28px;
      transition: all 0.2s ease;
      box-shadow: 0 4px 15px rgba(37, 99, 235, 0.4);
      display: flex;
      justify-content: center;
      align-items: center;
      gap: 8px;
    }
    .btn-save:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(37, 99, 235, 0.6);
    }
    .footer-links {
      margin-top: 24px;
      text-align: center;
      padding-top: 18px;
      border-top: 1px solid var(--border);
      font-size: 0.85rem;
      color: var(--muted);
    }
  </style>
</head>
<body>

  <div class="config-card">
    <div class="header">
      <h1>⚡ ESP32 Motor Protection Portal</h1>
      <p>Hardware Access Point Configuration & Threshold Parameters</p>
      <div class="badge">HOTSPOT IP: 192.168.4.1</div>
    </div>

    <form action="/save_config" method="POST">

      <div class="section-title">🛡️ Programmable Safety Protection Thresholds</div>
      <div class="form-grid">
        <div class="form-group">
          <label>Max Over-Voltage Trip Limit (V)</label>
          <input type="number" step="0.1" name="v_max" value="%V_MAX%" required>
        </div>
        <div class="form-group">
          <label>Min Under-Voltage Trip Limit (V)</label>
          <input type="number" step="0.1" name="v_min" value="%V_MIN%" required>
        </div>
        <div class="form-group">
          <label>Max Over-Current Trip Limit (A)</label>
          <input type="number" step="0.1" name="i_max" value="%I_MAX%" required>
        </div>
        <div class="form-group">
          <label>Max Temperature Trip Limit (°C)</label>
          <input type="number" step="0.1" name="t_max" value="%T_MAX%" required>
        </div>
        <div class="form-group">
          <label>Max Over-Speed Limit (RPM)</label>
          <input type="number" name="rpm_max" value="%RPM_MAX%" required>
        </div>
      </div>

      <div class="section-title">🌐 Wi-Fi Router Connection Credentials</div>
      <div class="form-grid">
        <div class="form-group">
          <label>Wi-Fi SSID (2.4GHz Network Name)</label>
          <input type="text" name="ssid" value="%SSID%" required>
        </div>
        <div class="form-group">
          <label>Wi-Fi Password</label>
          <input type="password" name="pass" value="%PASS%">
        </div>
      </div>

      <div class="section-title">☁️ HiveMQ Cloud MQTT SSL Broker Settings</div>
      <div class="form-grid">
        <div class="form-group">
          <label>HiveMQ Server Host</label>
          <input type="text" name="mqtt_server" value="%MQTT_SERVER%" required>
        </div>
        <div class="form-group">
          <label>MQTT SSL Port</label>
          <input type="number" name="mqtt_port" value="%MQTT_PORT%" required>
        </div>
        <div class="form-group">
          <label>MQTT Username</label>
          <input type="text" name="mqtt_user" value="%MQTT_USER%">
        </div>
        <div class="form-group">
          <label>MQTT Password</label>
          <input type="password" name="mqtt_pass" value="%MQTT_PASS%">
        </div>
      </div>

      <button type="submit" class="btn-save">💾 Save Configuration & Reboot ESP32</button>
    </form>

    <div class="footer-links">
      <p>Connect to Wi-Fi to stream live data to your GitHub Hosted SCADA Dashboard</p>
    </div>
  </div>

</body>
</html>
)rawliteral";

#endif
