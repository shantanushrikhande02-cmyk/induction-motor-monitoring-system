APPENDIX CODE FILES

Appendix A – Main ESP32 Firmware Code
File: Appendix_A_Main_ESP32_Firmware.ino

Appendix B – ESP32 Configuration Portal Code
File: Appendix_B_ESP32_Configuration_Portal.h

Appendix C – Web Dashboard Code
File: Appendix_C_Web_Dashboard.html

IMPORTANT NOTES
1. These files are based on the source files in the supplied ZIP.
2. MQTT broker host, username and password have been replaced with placeholders for safety. Enter your own credentials privately in your working copy; do not publish passwords in the thesis.
3. The supplied ZIP contains dashboard.html as a byte-for-byte duplicate of index.html, so only one copy is included.
4. The firmware pin comment for the ZMPT101B sensor says GPIO 27, while the code uses VOLTAGE_PIN (defined elsewhere in the sketch). Verify the comment against the actual wiring before changing it.
5. The source uses a speed sensor pin/comment labelled LM393. Your project description has called this an IR RPM sensor. Confirm the actual module and make the thesis/code terminology consistent; this package does not silently alter the hardware definition.
6. These source files have not been compiled or hardware-tested as part of preparing this appendix package.
